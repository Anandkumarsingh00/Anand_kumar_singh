
        const input = document.getElementById('todo-input');
        const addBtn = document.getElementById('add-btn');
        const list = document.getElementById('todo-list');
        const pointsEl = document.getElementById('points');
        const levelEl = document.getElementById('level');
        const streakEl = document.getElementById('streak');
        const completedEl = document.getElementById('completed');
        const plantEl = document.getElementById('plant');
        const progressEl = document.getElementById('progress');
        const plantMessage = document.getElementById('plant-message');
        const celebrationModal = document.getElementById('celebration');
        const celebrationTitle = document.getElementById('celebration-title');
        const celebrationMessage = document.getElementById('celebration-message');

        // Game state (stored in memory, not localStorage)
        const gameState = {
            todos: [],
            points: 0,
            level: 1,
            streak: 0,
            totalCompleted: 0,
            lastCompletedDate: null
        };

        const plantStages = ['🌱', '🌿', '🪴', '🌳', '🌸', '🌺', '🌻', '🌹'];
        const motivationalQuotes = [
            "You're crushing it!",
            "Productivity master!",
            "Keep the momentum going!",
            "You're on fire!",
            "Achievement unlocked!",
            "Level up your life!",
            "Quest completed like a boss!",
            "You're unstoppable!"
        ];

        function updateStats() {
            pointsEl.textContent = gameState.points;
            levelEl.textContent = gameState.level;
            streakEl.textContent = gameState.streak;
            completedEl.textContent = gameState.totalCompleted;
            
            // Update plant based on total completed tasks
            const plantStage = Math.min(Math.floor(gameState.totalCompleted / 3), plantStages.length - 1);
            plantEl.textContent = plantStages[plantStage];
            
            // Update progress bar
            const progressPercent = ((gameState.totalCompleted % 3) / 3) * 100;
            progressEl.style.width = progressPercent + '%';
            
            // Update plant message
            if (gameState.totalCompleted === 0) {
                plantMessage.textContent = 'Complete tasks to grow your plant!';
            } else if (plantStage < plantStages.length - 1) {
                plantMessage.textContent = `${3 - (gameState.totalCompleted % 3)} tasks until next growth!`;
            } else {
                plantMessage.textContent = '🎉 Your garden is fully bloomed!';
            }
            
            // Check for level up
            const newLevel = Math.floor(gameState.points / 100) + 1;
            if (newLevel > gameState.level) {
                gameState.level = newLevel;
                showCelebration('🏆 Level Up!', `You've reached Level ${newLevel}!`, 3000);
            }
        }

        function showCelebration(title, message, duration = 2000) {
            celebrationTitle.textContent = title;
            celebrationMessage.textContent = message;
            celebrationModal.classList.add('show');
            
            // Add confetti
            createConfetti();
            
            setTimeout(() => {
                celebrationModal.classList.remove('show');
            }, duration);
        }

        function createConfetti() {
            const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
            for (let i = 0; i < 50; i++) {
                setTimeout(() => {
                    const confetti = document.createElement('div');
                    confetti.className = 'confetti';
                    confetti.style.left = Math.random() * window.innerWidth + 'px';
                    confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
                    confetti.style.top = '0px';
                    document.body.appendChild(confetti);
                    
                    setTimeout(() => confetti.remove(), 3000);
                }, i * 30);
            }
        }

        function createTodoNode(todo, index) {
            const li = document.createElement('li');

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = !!todo.completed;
            checkbox.addEventListener("change", () => {
                todo.completed = checkbox.checked;
                textSpan.style.textDecoration = todo.completed ? 'line-through' : "";
                textSpan.style.opacity = todo.completed ? '0.6' : '1';
                
                if (todo.completed) {
                    // Award points
                    const points = 10;
                    gameState.points += points;
                    gameState.totalCompleted++;
                    gameState.streak++;
                    
                    const quote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
                    showCelebration('🎉 Quest Complete!', `+${points} points! ${quote}`);
                    
                    updateStats();
                } else {
                    // Remove points if unchecked
                    gameState.points = Math.max(0, gameState.points - 10);
                    gameState.totalCompleted = Math.max(0, gameState.totalCompleted - 1);
                    gameState.streak = Math.max(0, gameState.streak - 1);
                    updateStats();
                }
            });

            const textSpan = document.createElement("span");
            textSpan.textContent = todo.text;
            if (todo.completed) {
                textSpan.style.textDecoration = 'line-through';
                textSpan.style.opacity = '0.6';
            }
            
            textSpan.addEventListener("dblclick", () => {
                const newText = prompt("Edit quest", todo.text);
                if (newText !== null && newText.trim()) {
                    todo.text = newText.trim();
                    textSpan.textContent = todo.text;
                }
            });

            const delBtn = document.createElement('button');
            delBtn.textContent = "Delete";
            delBtn.addEventListener('click', () => {
                gameState.todos.splice(index, 1);
                render();
            });

            li.appendChild(checkbox);
            li.appendChild(textSpan);
            li.appendChild(delBtn);
            return li;
        }

        function render() {
            list.innerHTML = '';
            gameState.todos.forEach((todo, index) => {
                const node = createTodoNode(todo, index);
                list.appendChild(node);
            });
        }

        function addTodo() {
            const text = input.value.trim();
            if (!text) return;

            gameState.todos.push({ text: text, completed: false });
            input.value = '';
            render();
        }

        addBtn.addEventListener("click", addTodo);
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                addTodo();
            }
        });

        // Initialize
        updateStats();
        render();